Thanks for downloading this theme!

This theme is meant to work hand in hand with the CPO Content Types plugin. 
The plugin is very light, and you will need to install it in order to 
manage the main slider, homepage features, as well as the portfolio:
http://wordpress.org/plugins/cpo-content-types

If you have any questions regarding its usage, you can read the 
quickstart guide at the following URL:
http://www.cpothemes.com/documentation

Brilliance WordPress Theme, Copyright (C) 2015, CPOThemes
Brilliance is distributed under the terms of the GNU GPL

BUNDLED RESOURCES
All resources bundled with this theme are licensed or compatible 
with the GPLv2. Following is a list of all of them:

Font Awesome - http://fortawesome.github.io/Font-Awesome/
License: SIL OFL 1.1
Copyright: Dave Gandy

Jquery Cycle2 - http://jquery.malsup.com/cycle2/
License: Dual licensed under the MIT and GPL licenses.
Copyright: M. Alsup

HTML5 Shiv - https://github.com/aFarkas/html5shiv
License: Dual licensed under the MIT and GPL licenses.
Copyright: @afarkas @jdalton @jon_neal @rem

Magnific Popup - http://dimsemenov.com/plugins/magnific-popup/
License: MIT License
Copyright: Stephane Caron

Homepage Slider Image - http://jaymantri.com/
License: CC0 License
Copyright: Jay Mantri

All other image resources
License: GPLv2 General Public License
Copyright: Manuel Vicedo